# 🔐 VaultNotes

Tu segundo cerebro **local y 100% offline** para estudiar ciberseguridad: apuntes con editor rico, labs prácticos de SOC/IAM, glosario con flashcards inteligentes y backups en ZIP.

> Toda la información vive **en tu navegador** (IndexedDB). No hay servidor, no hay cuentas, no hay nube. Nadie más puede ver tus datos.

---

## 🚀 Cómo ejecutarla

```bash
bun install        # (o npm install)
bun run dev        # (o npm run dev) → abre http://localhost:3000
```

## 📖 Guía de uso

### 📊 Dashboard
- **Métricas**: total de apuntes, términos del glosario, favoritos y última edición.
- **Apuntes Recientes**: clic en cualquiera para abrirlo directamente.
- **Flashcards SMART**: estudio inteligente del glosario. Prioriza los términos que **fallas más**, los que **nunca has visto** y los que llevas **días sin repasar**. Cada carta muestra tu historial `✓ aciertos / ✗ fallos`. Tus estadísticas se guardan automáticamente.

### 📝 Apuntes (tu knowledge base)
Organización en 3 niveles: **Plataforma → Apuntes → Subpáginas (infinitas)**.

1. **Crear apunte**: botón `Nuevo` → elige plataforma, categorías (checklist maestro), pega la URL fuente si tiene.
2. **Subpáginas**: dentro de un apunte, botón `Nueva subpágina` al final. Sirven para desglosar temas (ej. *Zero Trust → Cómo funciona → Componentes*).
3. **Árbol desplegable**: al hacer clic en un apunte, sus subpáginas se despliegan ahí mismo en la lista. El botón `▸ N` colapsa/expande manualmente.
4. **Editor rico**: título, categoría, favorito (⭐), URL fuente. Toolbar con H1-H3, negrita, listas, checklist, citas y **bloques de código**. Autoguardado a los ~1.5s de dejar de escribir (indicador *Guardado* arriba).
5. **Imágenes**: pega con `Ctrl+V` o arrastra al editor (se guardan en la BD local).
6. **Tooltip de glosario**: pasa el mouse sobre un texto que coincida con un término del glosario y verás su definición flotante.
7. **Filtros**: por plataforma (izquierda), por categoría y búsqueda local (centro). Los paneles se **redimensionan arrastrando** el borde entre columnas (doble clic restaura).

### 🧪 Hands-On / Labs
Para documentar prácticas de LetsDefend, TryHackMe, HTB, laboratorios propios...

1. **Crear lab**: organización/plataforma, tema (lista maestra), dificultad, estado, tiempo invertido y link fuente.
2. **Fases / Partes**: cada parte tiene su propio editor rico (con imágenes y bloques de código). Se reordenan con ▲▼, se expanden/colapsan y se marcan como completadas.
3. **Herramientas Usadas**: agrega con `Enter`, elimina con `✕`. Las nuevas se guardan en tu lista maestra global.
4. **Comandos Clave**: chips individuales de comandos; `Copiar (N)` los manda todos al portapapeles.
5. **Resumen de investigación**: Hallazgos/IoCs y Mitigación/Lecciones aprendidas.
6. **Filtros** por organización, tema, estado y dificultad.

### 📚 Glosario
- Términos con sigla, definición corta (para tooltips) y completa, ejemplos múltiples, plataforma y **categorías del checklist maestro** (mismo que apuntes y labs).
- Cada término muestra **en qué apuntes aparece** (búsqueda automática por nombre o sigla).
- Modo estudio con flashcards 3D (clic para girar).

### 🗑️ Papelera
Todo lo eliminado va aquí (los apuntes arrastran a sus subpáginas). Restaurar o `Vaciar Papelera` (permanente).

### ⚙️ Configuración
Administra las **listas maestras** de categorías y herramientas, compartidas por las 3 secciones. No puedes borrar una que esté en uso.

### 🔍 Búsqueda global (`Ctrl+K`)
Fuzzy search en todo el vault: títulos, siglas, plataformas, contenido de apuntes y labs, herramientas y comandos. Navega con `↑↓`, abre con `Enter`.

### 💾 Backups (¡importante!)
- **Exportar ZIP**: descarga `vault-backup-YYYY-MM-DD.zip` con todos tus apuntes en Markdown, labs, glosario, imágenes y estadísticas de estudio.
- **Importar (.zip o .json)**: sincronización inteligente — agrega lo nuevo, **actualiza solo lo que cambió** y omite lo idéntico. Nunca duplica.

> ⚠️ **Tus datos viven en el navegador que uses.** Si limpias los datos de navegación o cambias de máquina/computador, el vault no viaja solo. **Exporta un ZIP de vez en cuando** y guárdalo en tu OneDrive/Drive/USB. Importarlo en otro navegador restaura todo.

## ⌨️ Atajos
| Atajo | Acción |
|---|---|
| `Ctrl+K` / `⌘K` | Búsqueda global |
| `Ctrl+V` | Pegar imagen en el editor |
| `Enter` | Agregar herramienta/comando en labs |
| Doble clic en borde | Restaurar ancho de panel |

## 🛠️ Stack
Vite + React 19 + TypeScript · Dexie (IndexedDB) · Tailwind CSS 4 · Fuse.js · JSZip · canvas-confetti
